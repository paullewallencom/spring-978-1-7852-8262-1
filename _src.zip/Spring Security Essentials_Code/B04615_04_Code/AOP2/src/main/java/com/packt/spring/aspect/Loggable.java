package com.packt.spring.aspect;

public @interface Loggable {

}
