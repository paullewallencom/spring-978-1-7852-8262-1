package com.packt.spring.aop.ui;

public abstract class UIComponent {
	protected String componentName;

	protected String getComponentName() {
		return componentName;
	}

}
