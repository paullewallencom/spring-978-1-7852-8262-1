package com.packt.wicket.spring.security;

import org.apache.wicket.markup.html.WebPage;

public class PublishPage extends WebPage {

}
